﻿using System;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using E_le1rning.Models;
using System.Web.Security;
using E_le1rning.App_Code.ElearningDataSetTableAdapters;

namespace E_le1rning.Account
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void LogIn(object sender, EventArgs e)
        {
            if (Membership.ValidateUser(UserName.Text, Password.Text))
            {
                if (Roles.IsUserInRole(UserName.Text, "Instructors"))
                {
                    InstructorsTableAdapter instructor = new InstructorsTableAdapter();
                    Session["instructorID"] = instructor.GetInstructorID(UserName.Text);
                  
                    FormsAuthentication.SetAuthCookie(UserName.Text, true);
                    Response.Redirect("~/Default.aspx");

                } 
                else if (Roles.IsUserInRole(UserName.Text, "Students"))
                {
                    StudentsTableAdapter student= new StudentsTableAdapter();
                    Session["studentID"] = student.GetStudentID(UserName.Text);
                    FormsAuthentication.SetAuthCookie(UserName.Text, true);
                    Response.Redirect("~/Default.aspx");

                }
                
            }
        }

    
    }
}