﻿using System;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using E_le1rning.Models;
using E_le1rning.App_Code.ElearningDataSetTableAdapters;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;
using System.Net.Mail;
using System.Configuration;
using System.Text;
using System.Net;
using System.Net.Mime;


namespace E_le1rning.Account
{
    public partial class ForgotPassword : Page
    {
        string OTPcode;
        Random rand = new Random();
       
        protected void Page_Load(object sender, EventArgs e)
        {
          
          
           
            
          

        }



        protected void Forgot(object sender, EventArgs e)
        { 
            try
            {


                OTPcode = (rand.Next(999999)).ToString();

                string cs = ConfigurationManager.ConnectionStrings["ElearningConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(cs);
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from aspnet_Membership where Email='" + Email.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows == true)
                {
                    dr.Read();
                    string email = dr["Email"].ToString();
                    string UserId = dr["UserId"].ToString();
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("Email :" + email);
                    sb.AppendLine("UserId: " + UserId);
                    sb.AppendLine("OtpCode"+OTPcode);
                    SmtpClient Client = new SmtpClient("smtp.gmail.com", 587);
                    Client.EnableSsl = true;
                    Client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    Client.UseDefaultCredentials = false;
                    Client.Credentials = new NetworkCredential("elmantibrahim3@gmail.com", "Salahsaid0");
                    MailMessage msg = new MailMessage();
                    msg.To.Add(Email.Text);
                    msg.From = new MailAddress("elmantibrahim3@gmail.Com");
                    msg.Subject = "Your UserId ";
                    msg.Body = sb.ToString();
                    Client.Send(msg);
                    Label1.Text = "Your Code securité has been sent to registred email id";
                    Response.Redirect("~/Account/ResetPassword.aspx?parm="+OTPcode+"");

                }
                else
                {
                    Label1.Text = "Invalid Email";
                }


            }catch(Exception ex)
            {
              Label1.Text= "L'utilisateur n'existe pas ou n'est pas confirmé.";
            }
        }

    }
}