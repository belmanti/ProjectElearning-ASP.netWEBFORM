﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using E_le1rning.Models;
using E_le1rning.App_Code.ElearningDataSetTableAdapters;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Security.Cryptography;

namespace E_le1rning.Account
{
    public partial class ResetPassword : Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {


            Panel1.Visible = false;
            Panel2.Visible = true;



        }
       
        protected string StatusMessage
        {
            get;
            private set;
        }

        protected void Reset_Click(object sender, EventArgs e)
        {
           
            string cs = ConfigurationManager.ConnectionStrings["ElearningConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            
            SqlCommand cmd = new SqlCommand("update aspnet_Membership set Password = '" + Password.Text+ "' where Email = '" + Email.Text + "' ", con);


            
            cmd.ExecuteNonQuery();
            Response.Redirect("~/Account/ResetPasswordConfirmation");
            

            /*
            string code = IdentityHelper.GetCodeFromRequest(Request);
            if (code != null)
            {
                var manager = Context.GetOwinContext().GetUserManager<ApplicationUserManager>();

                var user = manager.FindByName(Email.Text);
                if (user == null)
                {
                    ErrorMessage.Text = "Aucun utilisateur trouvé";
                    return;
                }
                var result = manager.ResetPassword(user.Id, code, Password.Text);
                if (result.Succeeded)
                {
                    Response.Redirect("~/Account/ResetPasswordConfirmation");
                    return;
                }
                ErrorMessage.Text = result.Errors.FirstOrDefault();
                return;
            }

            ErrorMessage.Text = "Une erreur s'est produite";*/
        }
        
        protected void Unnamed_Click(object sender, EventArgs e)
        {


                if (Request.QueryString["parm"].ToString() == OTP.Text)
                {
                    Label1.Text = "le code exact";
                    Panel1.Visible = true;
                    Panel2.Visible = false;
                }
                else
                    Label1.Text = "something wrong ";
            
        }
    }
}