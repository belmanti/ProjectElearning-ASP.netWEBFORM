﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using E_le1rning.Models;
using System.Web.Security;
using E_le1rning.App_Code.ElearningDataSetTableAdapters;

namespace E_le1rning.Account
{
    public partial class Register : Page
    {
        protected void CreateUser_Click(object sender, EventArgs e)
        {
           

            if (RadInstructor.Checked == true)
            {
               
                InstructorsTableAdapter instructor = new InstructorsTableAdapter();
                Membership.CreateUser(UserName.Text, Password.Text,Email.Text);
                Roles.AddUserToRole(UserName.Text, "Instructors");

                instructor.Insert(txtfullname.Text,UserName.Text);
             
                Response.Redirect("~/Default.aspx");
               
            }
            else if (RadStudent.Checked == true)
            {

                StudentsTableAdapter student = new StudentsTableAdapter();
                Membership.CreateUser(UserName.Text, Password.Text,Email.Text);
                Roles.AddUserToRole(UserName.Text, "Students");
                student.Insert(txtfullname.Text, UserName.Text);
                Response.Redirect("~/Default.aspx");

            }
           
        }
    }
}