﻿using System.Web.UI;

namespace E_le1rning.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}